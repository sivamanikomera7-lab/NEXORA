import {
  BarChart3,
  CreditCard,
  Edit3,
  Eye,
  EyeOff,
  FolderPlus,
  LayoutDashboard,
  LogOut,
  Mail,
  Package,
  Plus,
  Settings,
  ShoppingCart,
  Store,
  Trash2,
  Upload,
  Users,
} from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { RevenueChart } from '../../components/RevenueChart.tsx';
import { useApp } from '../../context/AppContext.tsx';
import { formatCurrency, formatShortDate } from '../../lib/format.ts';
import { PRESET_IMAGE_OPTIONS, resolveImageSrc } from '../../lib/images.ts';
import type { Category, Coupon, OrderRecord, Product } from '../../types.ts';

type AdminTab = 'overview' | 'products' | 'orders' | 'customers' | 'revenue' | 'settings' | 'messages';

interface OverviewResponse {
  metrics: {
    totalRevenue: number;
    totalOrders: number;
    todaySales: number;
    monthlySales: number;
    totalProducts: number;
    publishedProducts: number;
    totalCustomers: number;
  };
  charts: {
    daily: Array<{ bucket: string; revenue: number; orders: number }>;
    weekly: Array<{ bucket: string; revenue: number; orders: number }>;
    monthly: Array<{ bucket: string; revenue: number; orders: number }>;
  };
  recentOrders: OrderRecord[];
}

interface AdminCustomer {
  id: number;
  name: string;
  email: string;
  phone: string;
  company: string;
  created_at: string;
  order_count: number;
  total_spent: number;
  orders: Array<{
    id: number;
    order_number: string;
    total_amount: number;
    status: string;
    created_at: string;
    product_names: string;
  }>;
}

interface PaymentRecord {
  id: number;
  order_number: string;
  customer_name: string;
  customer_email: string;
  razorpay_order_id: string;
  razorpay_payment_id: string | null;
  amount: number;
  status: string;
  method: string;
  verified_at: string | null;
  created_at: string;
}

function AdminLoginGate() {
  const { refreshUser, navigate, showToast } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const resp = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email, password, requireAdminRole: true }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        setError(data.error || 'Administrator authentication failed.');
        return;
      }
      await refreshUser();
      showToast('Admin session authenticated.', 'success');
    } catch {
      setError('Network error authenticating administrator.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#05070E] flex items-center justify-center px-4">
      <div className="glass-panel w-full max-w-md rounded-2xl p-8 space-y-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-blue-400">
            NEXORA Admin Console
          </p>
          <h1 className="mt-2 font-display text-2xl font-bold text-white">Administrator Sign In</h1>
          <p className="mt-1 text-sm text-slate-400">
            Protected operations portal. Role-based verification is required.
          </p>
        </div>

        {error && (
          <div className="rounded-lg border border-rose-500/40 bg-rose-950/50 px-3.5 py-2.5 text-xs text-rose-200">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Admin Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@nexora.digital"
              className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white focus:border-blue-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter administrator password"
              className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white focus:border-blue-500 focus:outline-none"
            />
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="h-11 w-full rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-60 cursor-pointer"
          >
            {submitting ? 'Verifying...' : 'Sign In to Admin'}
          </button>
        </form>

        <div className="border-t border-white/[0.08] pt-4 flex items-center justify-between text-xs">
          <button
            type="button"
            onClick={() => {
              setEmail('admin@nexora.digital');
              setPassword('NexoraAdmin@2026');
            }}
            className="text-blue-400 hover:text-blue-300 cursor-pointer"
          >
            Fill Default Admin Credentials
          </button>
          <button
            type="button"
            onClick={() => navigate('/')}
            className="text-slate-400 hover:text-white cursor-pointer"
          >
            Back to Storefront
          </button>
        </div>
      </div>
    </div>
  );
}

export function AdminDashboard() {
  const { user, authLoading, logout, navigate, settings, refreshSettings, showToast } = useApp();
  const [tab, setTab] = useState<AdminTab>('overview');

  const [overview, setOverview] = useState<OverviewResponse | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [customers, setCustomers] = useState<AdminCustomer[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [messagesData, setMessagesData] = useState<{
    messages: Array<{ id: number; name: string; email: string; subject: string; message: string; status: string; created_at: string }>;
    subscribers: Array<{ id: number; email: string; created_at: string }>;
  }>({ messages: [], subscribers: [] });

  const [expandedCustomerId, setExpandedCustomerId] = useState<number | null>(null);

  // Product Form Modal State
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [prodForm, setProdForm] = useState({
    name: '',
    subtitle: '',
    description: '',
    price: '1499',
    discount_price: '999',
    category_id: '1',
    image_url: 'asset:prod_ebook_systems',
    file_token_path: '',
    file_name: 'NEXORA-Digital-Release.pdf',
    file_format: 'PDF',
    file_size_label: '12.0 MB',
    pages_or_duration: '120 Pages',
    preview_excerpt: '',
    highlightsText: '',
    is_featured: true,
    is_bestseller: false,
    is_new_arrival: true,
    is_published: true,
  });

  // New Category & Coupon Inputs
  const [newCatName, setNewCatName] = useState('');
  const [couponForm, setCouponForm] = useState({
    code: '',
    discount_type: 'percent' as 'percent' | 'fixed',
    discount_value: '20',
    min_order_amount: '0',
    max_uses: '250',
  });

  // Settings form
  const [settingsForm, setSettingsForm] = useState(settings);
  const [savingSettings, setSavingSettings] = useState(false);

  useEffect(() => {
    setSettingsForm(settings);
  }, [settings]);

  const loadTabData = useCallback(async (activeTab: AdminTab) => {
    try {
      if (activeTab === 'overview') {
        const res = await fetch('/api/admin/overview', { credentials: 'include' });
        if (res.ok) setOverview(await res.json());
      } else if (activeTab === 'products') {
        const [pRes, cRes] = await Promise.all([
          fetch('/api/admin/products', { credentials: 'include' }),
          fetch('/api/admin/categories', { credentials: 'include' }),
        ]);
        if (pRes.ok) setProducts(await pRes.json());
        if (cRes.ok) setCategories(await cRes.json());
      } else if (activeTab === 'orders') {
        const res = await fetch('/api/admin/orders', { credentials: 'include' });
        if (res.ok) setOrders(await res.json());
      } else if (activeTab === 'customers') {
        const res = await fetch('/api/admin/customers', { credentials: 'include' });
        if (res.ok) setCustomers(await res.json());
      } else if (activeTab === 'revenue') {
        const [oRes, payRes, coupRes] = await Promise.all([
          fetch('/api/admin/overview', { credentials: 'include' }),
          fetch('/api/admin/payments', { credentials: 'include' }),
          fetch('/api/admin/coupons', { credentials: 'include' }),
        ]);
        if (oRes.ok) setOverview(await oRes.json());
        if (payRes.ok) setPayments(await payRes.json());
        if (coupRes.ok) setCoupons(await coupRes.json());
      } else if (activeTab === 'messages') {
        const res = await fetch('/api/admin/messages', { credentials: 'include' });
        if (res.ok) setMessagesData(await res.json());
      }
    } catch {
      showToast('Failed to load admin records.', 'error');
    }
  }, [showToast]);

  useEffect(() => {
    if (user?.role === 'admin') {
      loadTabData(tab);
    }
  }, [user, tab, loadTabData]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#05070E] p-8">
        <div className="mx-auto max-w-6xl glass-panel h-80 animate-pulse rounded-2xl" />
      </div>
    );
  }

  if (!user || user.role !== 'admin') {
    return <AdminLoginGate />;
  }

  const openCreateProduct = () => {
    setEditingProduct(null);
    setProdForm({
      name: '',
      subtitle: '',
      description: '',
      price: '1499',
      discount_price: '999',
      category_id: String(categories[0]?.id || 1),
      image_url: 'asset:prod_ebook_systems',
      file_token_path: '',
      file_name: 'NEXORA-Digital-Asset.pdf',
      file_format: 'PDF',
      file_size_label: '10.0 MB',
      pages_or_duration: '120 Pages',
      preview_excerpt: '',
      highlightsText: 'Lifetime updates included\nInstant private signed PDF download',
      is_featured: false,
      is_bestseller: false,
      is_new_arrival: true,
      is_published: true,
    });
    setProductModalOpen(true);
  };

  const openEditProduct = (p: Product) => {
    setEditingProduct(p);
    setProdForm({
      name: p.name,
      subtitle: p.subtitle,
      description: p.description,
      price: String(p.price),
      discount_price: p.discount_price !== null ? String(p.discount_price) : '',
      category_id: String(p.category_id),
      image_url: p.image_url,
      file_token_path: '',
      file_name: p.file_name,
      file_format: p.file_format,
      file_size_label: p.file_size_label,
      pages_or_duration: p.pages_or_duration,
      preview_excerpt: p.preview_excerpt,
      highlightsText: (p.highlights || []).join('\n'),
      is_featured: p.is_featured,
      is_bestseller: p.is_bestseller,
      is_new_arrival: p.is_new_arrival,
      is_published: p.is_published,
    });
    setProductModalOpen(true);
  };

  const handleUploadImage = async (file: File, target: 'product' | 'logo') => {
    const fd = new FormData();
    fd.append('file', file);
    const resp = await fetch('/api/admin/upload/image', {
      method: 'POST',
      credentials: 'include',
      body: fd,
    });
    const data = await resp.json();
    if (!resp.ok) {
      showToast(data.error || 'Image upload failed.', 'error');
      return;
    }
    if (target === 'product') {
      setProdForm((f) => ({ ...f, image_url: data.imageUrl }));
    } else {
      setSettingsForm((s) => ({ ...s, logo_url: data.imageUrl }));
    }
    showToast('Image uploaded successfully.', 'success');
  };

  const handleUploadPrivatePdf = async (file: File) => {
    const fd = new FormData();
    fd.append('file', file);
    const resp = await fetch('/api/admin/upload/asset', {
      method: 'POST',
      credentials: 'include',
      body: fd,
    });
    const data = await resp.json();
    if (!resp.ok) {
      showToast(data.error || 'Asset upload failed.', 'error');
      return;
    }
    setProdForm((f) => ({
      ...f,
      file_token_path: data.fileTokenPath,
      file_name: data.fileName,
      file_size_label: data.fileSizeLabel,
    }));
    showToast(`Private asset "${data.fileName}" stored securely.`, 'success');
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      ...prodForm,
      price: Number(prodForm.price),
      discount_price: prodForm.discount_price ? Number(prodForm.discount_price) : null,
      category_id: Number(prodForm.category_id),
      highlights: prodForm.highlightsText
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean),
    };
    const url = editingProduct ? `/api/admin/products/${editingProduct.id}` : '/api/admin/products';
    const method = editingProduct ? 'PUT' : 'POST';
    const resp = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(payload),
    });
    const data = await resp.json();
    if (!resp.ok) {
      showToast(data.error || 'Failed to save product.', 'error');
      return;
    }
    setProductModalOpen(false);
    showToast(editingProduct ? 'Product updated.' : 'New digital product published.', 'success');
    loadTabData('products');
  };

  const togglePublish = async (p: Product) => {
    await fetch(`/api/admin/products/${p.id}/publish`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ is_published: !p.is_published }),
    });
    loadTabData('products');
  };

  const deleteProduct = async (id: number) => {
    const resp = await fetch(`/api/admin/products/${id}`, { method: 'DELETE', credentials: 'include' });
    const data = await resp.json();
    if (resp.ok) {
      showToast(data.message || 'Product removed.', 'info');
      loadTabData('products');
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    const resp = await fetch('/api/admin/categories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ name: newCatName.trim() }),
    });
    if (resp.ok) {
      setNewCatName('');
      showToast('Category added.', 'success');
      loadTabData('products');
    }
  };

  const handleDeleteCategory = async (id: number) => {
    const resp = await fetch(`/api/admin/categories/${id}`, { method: 'DELETE', credentials: 'include' });
    const d = await resp.json();
    if (!resp.ok) {
      showToast(d.error || 'Cannot delete category.', 'error');
      return;
    }
    loadTabData('products');
  };

  const handleCreateCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    const resp = await fetch('/api/admin/coupons', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({
        code: couponForm.code,
        discount_type: couponForm.discount_type,
        discount_value: Number(couponForm.discount_value),
        min_order_amount: Number(couponForm.min_order_amount),
        max_uses: Number(couponForm.max_uses),
      }),
    });
    const d = await resp.json();
    if (!resp.ok) {
      showToast(d.error || 'Could not create coupon.', 'error');
      return;
    }
    setCouponForm({ code: '', discount_type: 'percent', discount_value: '20', min_order_amount: '0', max_uses: '250' });
    showToast(`Coupon ${d.code} created.`, 'success');
    loadTabData('revenue');
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      const resp = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(settingsForm),
      });
      if (resp.ok) {
        await refreshSettings();
        showToast('Website settings updated live.', 'success');
      }
    } finally {
      setSavingSettings(false);
    }
  };

  const sidebarItems: Array<{ id: AdminTab; label: string; icon: typeof LayoutDashboard }> = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'products', label: 'Products & Files', icon: Package },
    { id: 'orders', label: 'Orders', icon: ShoppingCart },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'revenue', label: 'Revenue & Coupons', icon: BarChart3 },
    { id: 'settings', label: 'Website Settings', icon: Settings },
    { id: 'messages', label: 'Inquiries & Email', icon: Mail },
  ];

  return (
    <div className="min-h-screen bg-[#05070E] text-slate-100 flex flex-col lg:flex-row">
      {/* Sidebar (256px) */}
      <aside className="w-full lg:w-64 shrink-0 border-b lg:border-b-0 lg:border-r border-white/[0.08] bg-[#070B15] p-5 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-6">
            <span className="font-display text-base font-bold tracking-[0.14em] text-white">
              {settings.brand_name} ADMIN
            </span>
          </div>

          <nav className="flex lg:flex-col gap-1.5 overflow-x-auto pb-2 lg:pb-0">
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              const active = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTab(item.id)}
                  className={`flex items-center gap-3 rounded-lg px-3.5 py-2.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:bg-white/[0.05] hover:text-white'
                  }`}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="hidden lg:block border-t border-white/[0.08] pt-4 space-y-2">
          <p className="text-xs text-slate-400 truncate">{user.email}</p>
          <button
            type="button"
            onClick={() => navigate('/')}
            className="flex w-full items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-xs font-medium text-slate-300 hover:bg-white/[0.05] cursor-pointer"
          >
            <Store className="h-3.5 w-3.5" />
            <span>View Storefront</span>
          </button>
          <button
            type="button"
            onClick={logout}
            className="flex w-full items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-xs font-medium text-rose-300 hover:bg-rose-500/10 cursor-pointer"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content Workspace */}
      <div className="flex-1 min-w-0">
        <header className="flex h-16 items-center justify-between border-b border-white/[0.08] px-6">
          <p className="text-sm font-medium text-slate-300 capitalize">
            Admin Console / <span className="text-white font-semibold">{tab}</span>
          </p>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                setTab('products');
                openCreateProduct();
              }}
              className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 text-xs font-semibold text-white hover:bg-blue-500 whitespace-nowrap cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>New Product</span>
            </button>
          </div>
        </header>

        <main className="p-6 max-w-7xl mx-auto space-y-6">
          {/* OVERVIEW TAB */}
          {tab === 'overview' && overview && (
            <>
              <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
                {[
                  { label: 'Total Revenue', val: formatCurrency(overview.metrics.totalRevenue) },
                  { label: "Today's Sales", val: formatCurrency(overview.metrics.todaySales) },
                  { label: 'Monthly Sales', val: formatCurrency(overview.metrics.monthlySales) },
                  { label: 'Total Orders', val: String(overview.metrics.totalOrders) },
                  { label: 'Total Products', val: String(overview.metrics.totalProducts) },
                  { label: 'Total Customers', val: String(overview.metrics.totalCustomers) },
                ].map((kpi) => (
                  <div key={kpi.label} className="glass-panel rounded-xl p-4">
                    <p className="text-xs text-slate-400">{kpi.label}</p>
                    <p className="mt-2 font-mono text-xl font-bold text-white tabular-nums">{kpi.val}</p>
                  </div>
                ))}
              </div>

              <RevenueChart
                daily={overview.charts.daily}
                weekly={overview.charts.weekly}
                monthly={overview.charts.monthly}
              />

              <div className="glass-panel rounded-2xl overflow-hidden">
                <div className="border-b border-white/[0.08] px-6 py-4 flex items-center justify-between">
                  <h2 className="font-display text-base font-semibold text-white">Recent Orders</h2>
                  <button
                    type="button"
                    onClick={() => setTab('orders')}
                    className="text-xs font-medium text-blue-400 hover:text-blue-300 cursor-pointer"
                  >
                    View All Orders
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="border-b border-white/[0.07] text-slate-400">
                      <tr>
                        <th className="px-6 py-3 font-medium">Order ID</th>
                        <th className="px-6 py-3 font-medium">Customer</th>
                        <th className="px-6 py-3 font-medium">Products</th>
                        <th className="px-6 py-3 font-medium">Status</th>
                        <th className="px-6 py-3 font-medium text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.05]">
                      {overview.recentOrders.map((o) => (
                        <tr key={o.id} className="hover:bg-white/[0.02]">
                          <td className="px-6 py-3.5 font-mono text-white tabular-nums">{o.order_number}</td>
                          <td className="px-6 py-3.5">
                            <p className="text-slate-200 font-medium">{o.customer_name}</p>
                            <p className="text-slate-500">{o.customer_email}</p>
                          </td>
                          <td className="px-6 py-3.5 text-slate-300 max-w-xs truncate">{o.product_names}</td>
                          <td className="px-6 py-3.5 capitalize font-medium text-emerald-400">{o.status}</td>
                          <td className="px-6 py-3.5 text-right font-mono text-white tabular-nums">
                            {formatCurrency(o.total_amount)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* PRODUCTS & CATEGORIES TAB */}
          {tab === 'products' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="font-display text-xl font-bold text-white">Product Catalog &amp; Private Assets</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Manage pricing, discounts, product images, and private PDF files.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={openCreateProduct}
                  className="inline-flex h-10 items-center gap-2 rounded-lg bg-blue-600 px-4 text-xs font-semibold text-white hover:bg-blue-500 cursor-pointer"
                >
                  <Plus className="h-4 w-4" />
                  <span>Add New Product</span>
                </button>
              </div>

              <div className="glass-panel rounded-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="border-b border-white/[0.08] text-slate-400">
                      <tr>
                        <th className="px-5 py-3.5 font-medium">Product</th>
                        <th className="px-5 py-3.5 font-medium">Category</th>
                        <th className="px-5 py-3.5 font-medium text-right">Price</th>
                        <th className="px-5 py-3.5 font-medium text-right">Sales</th>
                        <th className="px-5 py-3.5 font-medium">Visibility</th>
                        <th className="px-5 py-3.5 font-medium text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.06]">
                      {products.map((p) => (
                        <tr key={p.id} className="hover:bg-white/[0.02]">
                          <td className="px-5 py-3.5">
                            <div className="flex items-center gap-3">
                              <img
                                src={resolveImageSrc(p.image_url)}
                                alt={p.name}
                                className="h-10 w-12 rounded-md object-cover bg-slate-900 shrink-0"
                              />
                              <div>
                                <p className="font-semibold text-white">{p.name}</p>
                                <p className="text-slate-400 font-mono">{p.file_name}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-3.5 text-slate-300">{p.category_name}</td>
                          <td className="px-5 py-3.5 text-right font-mono tabular-nums">
                            <span className="text-white font-semibold">
                              {formatCurrency(p.discount_price ?? p.price)}
                            </span>
                            {p.discount_price && (
                              <span className="ml-1.5 text-slate-500 line-through">
                                {formatCurrency(p.price)}
                              </span>
                            )}
                          </td>
                          <td className="px-5 py-3.5 text-right font-mono text-slate-200 tabular-nums">
                            {p.sales_count}
                          </td>
                          <td className="px-5 py-3.5">
                            <button
                              type="button"
                              onClick={() => togglePublish(p)}
                              className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 font-medium cursor-pointer ${
                                p.is_published
                                  ? 'bg-emerald-500/15 text-emerald-300'
                                  : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              {p.is_published ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
                              <span>{p.is_published ? 'Published' : 'Draft'}</span>
                            </button>
                          </td>
                          <td className="px-5 py-3.5 text-right space-x-2">
                            <button
                              type="button"
                              onClick={() => openEditProduct(p)}
                              className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-white/10 text-slate-300 hover:bg-white/10 cursor-pointer"
                              aria-label={`Edit ${p.name}`}
                            >
                              <Edit3 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => deleteProduct(p.id)}
                              className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-white/10 text-rose-400 hover:bg-rose-500/15 cursor-pointer"
                              aria-label={`Delete ${p.name}`}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Category Management */}
              <div className="glass-panel rounded-2xl p-6 space-y-4">
                <h3 className="font-display text-base font-semibold text-white">Manage Categories</h3>
                <form onSubmit={handleAddCategory} className="flex flex-wrap gap-3">
                  <input
                    type="text"
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    placeholder="New category name (e.g. Prompt Libraries)"
                    className="h-10 flex-1 min-w-[220px] rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white focus:border-blue-500 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="inline-flex h-10 items-center gap-2 rounded-lg bg-white/10 px-4 text-xs font-semibold text-white hover:bg-white/20 cursor-pointer"
                  >
                    <FolderPlus className="h-4 w-4" />
                    <span>Add Category</span>
                  </button>
                </form>

                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-3">
                  {categories.map((c) => (
                    <div
                      key={c.id}
                      className="flex items-center justify-between rounded-lg border border-white/[0.08] bg-white/[0.02] px-3.5 py-2.5 text-xs"
                    >
                      <div>
                        <p className="font-semibold text-white">{c.name}</p>
                        <p className="text-slate-500 tabular-nums">{c.product_count ?? 0} products</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDeleteCategory(c.id)}
                        className="text-slate-500 hover:text-rose-400 cursor-pointer p-1"
                        aria-label={`Delete category ${c.name}`}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ORDERS TAB */}
          {tab === 'orders' && (
            <div className="glass-panel rounded-2xl overflow-hidden">
              <div className="border-b border-white/[0.08] px-6 py-4">
                <h2 className="font-display text-lg font-semibold text-white">All Orders &amp; Download Status</h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-white/[0.08] text-slate-400">
                    <tr>
                      <th className="px-5 py-3.5 font-medium">Order ID</th>
                      <th className="px-5 py-3.5 font-medium">Customer Name &amp; Email</th>
                      <th className="px-5 py-3.5 font-medium">Product Name</th>
                      <th className="px-5 py-3.5 font-medium">Payment Status</th>
                      <th className="px-5 py-3.5 font-medium">Order Date</th>
                      <th className="px-5 py-3.5 font-medium">Download Status</th>
                      <th className="px-5 py-3.5 font-medium text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.06]">
                    {orders.map((o) => (
                      <tr key={o.id} className="hover:bg-white/[0.02]">
                        <td className="px-5 py-3.5 font-mono font-semibold text-white tabular-nums">
                          {o.order_number}
                        </td>
                        <td className="px-5 py-3.5">
                          <p className="font-medium text-slate-200">{o.customer_name}</p>
                          <p className="text-slate-400">{o.customer_email}</p>
                        </td>
                        <td className="px-5 py-3.5 text-slate-300 max-w-xs truncate">{o.product_names}</td>
                        <td className="px-5 py-3.5 capitalize font-medium text-emerald-400">{o.status}</td>
                        <td className="px-5 py-3.5 text-slate-400 tabular-nums">
                          {formatShortDate(o.created_at)}
                        </td>
                        <td className="px-5 py-3.5 text-slate-300 tabular-nums">
                          {(o.total_downloads ?? 0) > 0
                            ? `Downloaded (${o.total_downloads}x)`
                            : o.status === 'paid'
                              ? 'Unlocked · Ready'
                              : 'Locked'}
                        </td>
                        <td className="px-5 py-3.5 text-right font-mono text-white tabular-nums">
                          {formatCurrency(o.total_amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* CUSTOMERS TAB */}
          {tab === 'customers' && (
            <div className="glass-panel rounded-2xl overflow-hidden">
              <div className="border-b border-white/[0.08] px-6 py-4">
                <h2 className="font-display text-lg font-semibold text-white">Customer Directory &amp; History</h2>
              </div>
              <div className="divide-y divide-white/[0.07]">
                {customers.map((c) => {
                  const open = expandedCustomerId === c.id;
                  return (
                    <div key={c.id} className="p-5">
                      <div className="flex flex-wrap items-center justify-between gap-4">
                        <div>
                          <p className="text-sm font-semibold text-white">{c.name}</p>
                          <p className="text-xs text-slate-400">
                            {c.email} {c.company ? `· ${c.company}` : ''} {c.phone ? `· ${c.phone}` : ''}
                          </p>
                        </div>
                        <div className="flex items-center gap-6 text-xs">
                          <div className="text-right tabular-nums">
                            <p className="text-slate-400">Orders: {c.order_count}</p>
                            <p className="font-mono font-semibold text-white">
                              {formatCurrency(c.total_spent)}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => setExpandedCustomerId(open ? null : c.id)}
                            className="rounded-lg border border-white/12 px-3 py-1.5 text-xs font-medium text-blue-400 hover:bg-white/[0.05] cursor-pointer"
                          >
                            {open ? 'Hide History' : 'Purchase History'}
                          </button>
                        </div>
                      </div>

                      {open && (
                        <div className="mt-4 border-t border-white/[0.06] pt-3 space-y-2 text-xs">
                          {c.orders.length === 0 ? (
                            <p className="text-slate-500">No purchases recorded yet.</p>
                          ) : (
                            c.orders.map((ord) => (
                              <div
                                key={ord.id}
                                className="flex flex-wrap justify-between gap-2 text-slate-300 py-1"
                              >
                                <span className="font-mono text-white">{ord.order_number}</span>
                                <span className="flex-1 truncate px-3 text-slate-400">{ord.product_names}</span>
                                <span className="tabular-nums text-slate-400">{formatShortDate(ord.created_at)}</span>
                                <span className="font-mono text-emerald-400 tabular-nums">
                                  {formatCurrency(ord.total_amount)}
                                </span>
                              </div>
                            ))
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* REVENUE & COUPONS TAB */}
          {tab === 'revenue' && (
            <div className="space-y-6">
              {overview && (
                <RevenueChart
                  daily={overview.charts.daily}
                  weekly={overview.charts.weekly}
                  monthly={overview.charts.monthly}
                />
              )}

              {/* Coupon Manager */}
              <div className="glass-panel rounded-2xl p-6 space-y-4">
                <h3 className="font-display text-base font-semibold text-white">Coupon Codes</h3>
                <form onSubmit={handleCreateCoupon} className="grid grid-cols-1 gap-3 sm:grid-cols-5">
                  <input
                    type="text"
                    required
                    value={couponForm.code}
                    onChange={(e) => setCouponForm({ ...couponForm, code: e.target.value.toUpperCase() })}
                    placeholder="CODE (e.g. PRO25)"
                    className="h-10 rounded-lg border border-white/12 bg-white/[0.04] px-3 text-xs text-white"
                  />
                  <select
                    value={couponForm.discount_type}
                    onChange={(e) =>
                      setCouponForm({
                        ...couponForm,
                        discount_type: e.target.value as 'percent' | 'fixed',
                      })
                    }
                    className="h-10 rounded-lg border border-white/12 bg-[#0B101D] px-3 text-xs text-white"
                  >
                    <option value="percent">Percent (%)</option>
                    <option value="fixed">Fixed (INR)</option>
                  </select>
                  <input
                    type="number"
                    required
                    min="1"
                    value={couponForm.discount_value}
                    onChange={(e) => setCouponForm({ ...couponForm, discount_value: e.target.value })}
                    placeholder="Value"
                    className="h-10 rounded-lg border border-white/12 bg-white/[0.04] px-3 text-xs text-white"
                  />
                  <input
                    type="number"
                    min="0"
                    value={couponForm.min_order_amount}
                    onChange={(e) => setCouponForm({ ...couponForm, min_order_amount: e.target.value })}
                    placeholder="Min Order INR"
                    className="h-10 rounded-lg border border-white/12 bg-white/[0.04] px-3 text-xs text-white"
                  />
                  <button
                    type="submit"
                    className="h-10 rounded-lg bg-blue-600 text-xs font-semibold text-white hover:bg-blue-500 cursor-pointer"
                  >
                    Create Coupon
                  </button>
                </form>

                <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                  {coupons.map((cp) => (
                    <div
                      key={cp.id}
                      className="flex items-center justify-between rounded-lg border border-white/[0.08] bg-white/[0.02] px-4 py-3 text-xs"
                    >
                      <div>
                        <p className="font-mono font-bold text-white">{cp.code}</p>
                        <p className="text-slate-400 tabular-nums">
                          {cp.discount_type === 'percent' ? `${cp.discount_value}% off` : `${formatCurrency(cp.discount_value)} off`} · Used {cp.used_count}/{cp.max_uses}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={async () => {
                          await fetch(`/api/admin/coupons/${cp.id}`, {
                            method: 'PATCH',
                            headers: { 'Content-Type': 'application/json' },
                            credentials: 'include',
                            body: JSON.stringify({ is_active: !cp.is_active }),
                          });
                          loadTabData('revenue');
                        }}
                        className={`rounded px-2.5 py-1 font-medium cursor-pointer ${
                          cp.is_active ? 'bg-emerald-500/15 text-emerald-300' : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {cp.is_active ? 'Active' : 'Paused'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Razorpay Payment Records */}
              <div className="glass-panel rounded-2xl overflow-hidden">
                <div className="border-b border-white/[0.08] px-6 py-4 flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-blue-400" />
                  <h3 className="font-display text-base font-semibold text-white">Razorpay Payment Records</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="border-b border-white/[0.08] text-slate-400">
                      <tr>
                        <th className="px-5 py-3 font-medium">Order</th>
                        <th className="px-5 py-3 font-medium">Razorpay Order ID</th>
                        <th className="px-5 py-3 font-medium">Razorpay Payment ID</th>
                        <th className="px-5 py-3 font-medium">Method</th>
                        <th className="px-5 py-3 font-medium">Status</th>
                        <th className="px-5 py-3 font-medium text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.05]">
                      {payments.map((pay) => (
                        <tr key={pay.id}>
                          <td className="px-5 py-3 font-mono text-white">{pay.order_number}</td>
                          <td className="px-5 py-3 font-mono text-slate-300">{pay.razorpay_order_id}</td>
                          <td className="px-5 py-3 font-mono text-slate-300">{pay.razorpay_payment_id || '—'}</td>
                          <td className="px-5 py-3 uppercase text-slate-400">{pay.method}</td>
                          <td className="px-5 py-3 capitalize font-medium text-emerald-400">{pay.status}</td>
                          <td className="px-5 py-3 text-right font-mono text-white tabular-nums">
                            {formatCurrency(pay.amount)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* WEBSITE SETTINGS TAB */}
          {tab === 'settings' && (
            <form onSubmit={handleSaveSettings} className="glass-panel rounded-2xl p-6 sm:p-8 space-y-6">
              <div>
                <h2 className="font-display text-xl font-bold text-white">Website Settings</h2>
                <p className="text-xs text-slate-400 mt-1">
                  Changes apply immediately across the live customer storefront, navigation, and footer.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Website / Brand Name</label>
                  <input
                    type="text"
                    value={settingsForm.brand_name}
                    onChange={(e) => setSettingsForm({ ...settingsForm, brand_name: e.target.value })}
                    className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Tagline</label>
                  <input
                    type="text"
                    value={settingsForm.tagline}
                    onChange={(e) => setSettingsForm({ ...settingsForm, tagline: e.target.value })}
                    className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Logo URL (or Upload Custom Logo)
                  </label>
                  <div className="flex gap-3">
                    <input
                      type="text"
                      value={settingsForm.logo_url}
                      onChange={(e) => setSettingsForm({ ...settingsForm, logo_url: e.target.value })}
                      placeholder="Leave empty for geometric monogram or paste/upload image URL"
                      className="h-11 flex-1 rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                    />
                    <label className="inline-flex h-11 items-center gap-2 rounded-lg border border-white/15 bg-white/[0.05] px-4 text-xs font-semibold text-white hover:bg-white/[0.1] cursor-pointer">
                      <Upload className="h-4 w-4" />
                      <span>Upload Logo</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) handleUploadImage(f, 'logo');
                        }}
                      />
                    </label>
                  </div>
                </div>
              </div>

              <div className="border-t border-white/[0.08] pt-6 space-y-4">
                <h3 className="text-sm font-semibold text-white">Homepage Hero Content</h3>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Hero Headline</label>
                  <input
                    type="text"
                    value={settingsForm.hero_title}
                    onChange={(e) => setSettingsForm({ ...settingsForm, hero_title: e.target.value })}
                    className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Hero Subtitle</label>
                  <textarea
                    rows={3}
                    value={settingsForm.hero_subtitle}
                    onChange={(e) => setSettingsForm({ ...settingsForm, hero_subtitle: e.target.value })}
                    className="w-full rounded-lg border border-white/12 bg-white/[0.04] p-3.5 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Hero Primary CTA Text</label>
                  <input
                    type="text"
                    value={settingsForm.hero_cta_text}
                    onChange={(e) => setSettingsForm({ ...settingsForm, hero_cta_text: e.target.value })}
                    className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                  />
                </div>
              </div>

              <div className="border-t border-white/[0.08] pt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Support Email</label>
                  <input
                    type="email"
                    value={settingsForm.contact_email}
                    onChange={(e) => setSettingsForm({ ...settingsForm, contact_email: e.target.value })}
                    className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Support Phone</label>
                  <input
                    type="text"
                    value={settingsForm.contact_phone}
                    onChange={(e) => setSettingsForm({ ...settingsForm, contact_phone: e.target.value })}
                    className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Office Address</label>
                  <input
                    type="text"
                    value={settingsForm.contact_address}
                    onChange={(e) => setSettingsForm({ ...settingsForm, contact_address: e.target.value })}
                    className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                  />
                </div>
              </div>

              <div className="border-t border-white/[0.08] pt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Twitter / X URL</label>
                  <input
                    type="url"
                    value={settingsForm.twitter_url}
                    onChange={(e) => setSettingsForm({ ...settingsForm, twitter_url: e.target.value })}
                    className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">GitHub URL</label>
                  <input
                    type="url"
                    value={settingsForm.github_url}
                    onChange={(e) => setSettingsForm({ ...settingsForm, github_url: e.target.value })}
                    className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">LinkedIn URL</label>
                  <input
                    type="url"
                    value={settingsForm.linkedin_url}
                    onChange={(e) => setSettingsForm({ ...settingsForm, linkedin_url: e.target.value })}
                    className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Instagram URL</label>
                  <input
                    type="url"
                    value={settingsForm.instagram_url}
                    onChange={(e) => setSettingsForm({ ...settingsForm, instagram_url: e.target.value })}
                    className="h-11 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3.5 text-sm text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={savingSettings}
                className="h-11 rounded-xl bg-blue-600 px-6 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-60 cursor-pointer"
              >
                {savingSettings ? 'Saving Settings...' : 'Publish Website Settings'}
              </button>
            </form>
          )}

          {/* MESSAGES & SUBSCRIBERS TAB */}
          {tab === 'messages' && (
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
              <div className="glass-panel rounded-2xl p-6 lg:col-span-8 space-y-4">
                <h2 className="font-display text-lg font-semibold text-white">Contact Inquiries</h2>
                {messagesData.messages.length === 0 ? (
                  <p className="text-sm text-slate-400">No contact inquiries submitted yet.</p>
                ) : (
                  <div className="space-y-3">
                    {messagesData.messages.map((m) => (
                      <div key={m.id} className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-4 space-y-2">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <p className="text-sm font-semibold text-white">
                            {m.subject} <span className="text-xs font-normal text-slate-400">from {m.name} ({m.email})</span>
                          </p>
                          <select
                            value={m.status}
                            onChange={async (e) => {
                              await fetch(`/api/admin/messages/${m.id}`, {
                                method: 'PATCH',
                                headers: { 'Content-Type': 'application/json' },
                                credentials: 'include',
                                body: JSON.stringify({ status: e.target.value }),
                              });
                              loadTabData('messages');
                            }}
                            className="rounded border border-white/12 bg-[#0B101D] px-2.5 py-1 text-xs text-slate-200"
                          >
                            <option value="new">New</option>
                            <option value="reviewed">Reviewed</option>
                            <option value="resolved">Resolved</option>
                          </select>
                        </div>
                        <p className="text-xs leading-relaxed text-slate-300">{m.message}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="glass-panel rounded-2xl p-6 lg:col-span-4 space-y-4">
                <h2 className="font-display text-lg font-semibold text-white">
                  Newsletter ({messagesData.subscribers.length})
                </h2>
                {messagesData.subscribers.length === 0 ? (
                  <p className="text-sm text-slate-400">No subscribers yet.</p>
                ) : (
                  <ul className="space-y-2 text-xs text-slate-300">
                    {messagesData.subscribers.map((s) => (
                      <li key={s.id} className="flex justify-between border-b border-white/[0.05] pb-1.5">
                        <span className="truncate">{s.email}</span>
                        <span className="text-slate-500 tabular-nums">{formatShortDate(s.created_at)}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Add / Edit Product Modal */}
      {productModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setProductModalOpen(false)} />
          <form
            onSubmit={handleSaveProduct}
            className="relative z-10 max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-white/12 bg-[#080D1A] p-6 sm:p-8 space-y-5"
          >
            <h2 className="font-display text-xl font-bold text-white">
              {editingProduct ? `Edit: ${editingProduct.name}` : 'Add New Digital Product'}
            </h2>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-300 mb-1">Product Name</label>
                <input
                  type="text"
                  required
                  value={prodForm.name}
                  onChange={(e) => setProdForm({ ...prodForm, name: e.target.value })}
                  className="h-10 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3 text-sm text-white"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-300 mb-1">Short Subtitle</label>
                <input
                  type="text"
                  value={prodForm.subtitle}
                  onChange={(e) => setProdForm({ ...prodForm, subtitle: e.target.value })}
                  className="h-10 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3 text-sm text-white"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-300 mb-1">Description</label>
                <textarea
                  rows={3}
                  required
                  value={prodForm.description}
                  onChange={(e) => setProdForm({ ...prodForm, description: e.target.value })}
                  className="w-full rounded-lg border border-white/12 bg-white/[0.04] p-3 text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Category</label>
                <select
                  value={prodForm.category_id}
                  onChange={(e) => setProdForm({ ...prodForm, category_id: e.target.value })}
                  className="h-10 w-full rounded-lg border border-white/12 bg-[#0B101D] px-3 text-sm text-white"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Price (INR)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={prodForm.price}
                    onChange={(e) => setProdForm({ ...prodForm, price: e.target.value })}
                    className="h-10 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3 text-sm text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Discount Price</label>
                  <input
                    type="number"
                    min="0"
                    value={prodForm.discount_price}
                    onChange={(e) => setProdForm({ ...prodForm, discount_price: e.target.value })}
                    placeholder="Optional"
                    className="h-10 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3 text-sm text-white font-mono"
                  />
                </div>
              </div>

              {/* Product Cover Image Upload or Preset */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Product Cover Image</label>
                <select
                  value={prodForm.image_url.startsWith('/uploads/') ? 'custom' : prodForm.image_url}
                  onChange={(e) => {
                    if (e.target.value !== 'custom') setProdForm({ ...prodForm, image_url: e.target.value });
                  }}
                  className="h-10 w-full rounded-lg border border-white/12 bg-[#0B101D] px-3 text-xs text-white"
                >
                  {PRESET_IMAGE_OPTIONS.map((opt) => (
                    <option key={opt.key} value={opt.key}>
                      {opt.label}
                    </option>
                  ))}
                  {prodForm.image_url.startsWith('/uploads/') && (
                    <option value="custom">Uploaded Custom Image</option>
                  )}
                </select>
                <label className="mt-2 inline-flex items-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 cursor-pointer">
                  <Upload className="h-3.5 w-3.5" />
                  <span>Or upload product image</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) handleUploadImage(f, 'product');
                    }}
                  />
                </label>
              </div>

              {/* Private PDF / Digital Asset Upload */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Private Digital File (PDF / ZIP)
                </label>
                <div className="rounded-lg border border-dashed border-white/15 bg-white/[0.02] p-2.5 text-xs">
                  <p className="text-slate-300 truncate font-mono">{prodForm.file_name}</p>
                  <label className="mt-1 inline-flex items-center gap-1.5 text-blue-400 hover:text-blue-300 cursor-pointer">
                    <Upload className="h-3.5 w-3.5" />
                    <span>Upload private PDF/archive</span>
                    <input
                      type="file"
                      accept=".pdf,.zip,.epub,.fig"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) handleUploadPrivatePdf(f);
                      }}
                    />
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Format Label</label>
                  <input
                    type="text"
                    value={prodForm.file_format}
                    onChange={(e) => setProdForm({ ...prodForm, file_format: e.target.value })}
                    className="h-10 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Pages / Duration</label>
                  <input
                    type="text"
                    value={prodForm.pages_or_duration}
                    onChange={(e) => setProdForm({ ...prodForm, pages_or_duration: e.target.value })}
                    className="h-10 w-full rounded-lg border border-white/12 bg-white/[0.04] px-3 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Highlights (1 per line)</label>
                <textarea
                  rows={2}
                  value={prodForm.highlightsText}
                  onChange={(e) => setProdForm({ ...prodForm, highlightsText: e.target.value })}
                  className="w-full rounded-lg border border-white/12 bg-white/[0.04] p-2.5 text-xs text-white"
                />
              </div>

              <div className="sm:col-span-2 flex flex-wrap gap-5 pt-1 text-xs text-slate-300">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={prodForm.is_published}
                    onChange={(e) => setProdForm({ ...prodForm, is_published: e.target.checked })}
                  />
                  <span>Published</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={prodForm.is_featured}
                    onChange={(e) => setProdForm({ ...prodForm, is_featured: e.target.checked })}
                  />
                  <span>Featured</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={prodForm.is_bestseller}
                    onChange={(e) => setProdForm({ ...prodForm, is_bestseller: e.target.checked })}
                  />
                  <span>Best Seller</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={prodForm.is_new_arrival}
                    onChange={(e) => setProdForm({ ...prodForm, is_new_arrival: e.target.checked })}
                  />
                  <span>New Arrival</span>
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-3 border-t border-white/[0.08] pt-4">
              <button
                type="button"
                onClick={() => setProductModalOpen(false)}
                className="h-10 rounded-lg border border-white/12 px-4 text-xs font-medium text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="h-10 rounded-lg bg-blue-600 px-5 text-xs font-semibold text-white hover:bg-blue-500 cursor-pointer"
              >
                {editingProduct ? 'Save Changes' : 'Create Product'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
